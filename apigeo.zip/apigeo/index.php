<?php 
/** --> Require_once <-- */
require_once('app/Requete.php');
require_once('app/Document.php');

/** --> Regions, departement : Requête API <-- */
/** 1. Regions */
$regions = Requete::request('https://geo.api.gouv.fr/regions');
/** 2. Departements */
if (isset($_GET['region']) && ($_GET['region'] != 'regions')) 
{
    $departements = Requete::request('https://geo.api.gouv.fr/regions/'.Requete::get($_GET['region']).'/departements');
}
/** 3. Communes */
isset($_GET['departement']) ? 
$communes = Requete::request('https://geo.api.gouv.fr/departements/'.Requete::get($_GET['departement']).'/communes'):
"";

/** --> Header <-- */
echo(Document::header()); 
?>

<!-- Formulaire -->
<div class="container">
    <a class="d-flex justify-content-center" href="index.php"><button class="btn btn-warning btn-sm">Accueil</button></a>
    <?php
    if (isset($_GET['region']) || !isset($_GET['region']) && !isset($_GET['departement']))
    {?>
    <form method="GET">
        <div class="input-group mb-3">
            <!-- Formulaire regions -->
                <select class="custom-select custom-select-sm" name="region">
                    <option value="regions">Choisir une région</option>
                    <?php
                    foreach ($regions as $region) 
                    {
                        echo '<option value="'. $region->code .'">' . $region->nom . '</option>';
                    }?>
                </select>
            <!-- /Formulaire regions -->
            <div class="input-group-append">
                <button class="btn btn-outline-success btn-sm" type="submit">Validation</button>
            </div>
        </div>
    </form>
<?php
}?>

<!-- Liste -->
    <ul class="list-group">
        <?php
        /** --> Conditions dans l'url : $_GET['region'] */
        if (isset($_GET['region']) && $_GET['region'] !== 'regions')
        {
            foreach ($departements as $departement) 
            {
                echo '<a href="index.php?departement='.$departement->code.'"><li class="list-group-item">' . $departement->nom . '</li></a>';
            }
        }

        /** --> Conditions dans l'url : $_GET['departement'] */
        if (isset($_GET['departement']))
        { 
            foreach ($communes as $commune) 
            {
                if (isset($commune->population))
                {
                    echo '<li class="list-group-item">' . $commune->nom . '<span> <b>Population : ' . $commune->population .  '</b></span></li>';
                }
                else{
                    echo '<li class="list-group-item">' . $commune->nom . '</li>';
                }
            }
        }
        ?>
    </ul>
</div>

<?php
/** --> Footer <-- */
echo(Document::footer());

/** Reste à faire : 
 * - Gestion de toute les erreurs possibles par rapport aux routes.
 */
?>














