<?php
require_once('../app/Document.php');
/** --> Header <-- */
echo(Document::header());
?>

<div class="alert alert-danger" role="alert">
    Il y'a dû avoir une erreur 
</div>

<?php
/** --> Footer <-- */
echo(Document::footer());
?>