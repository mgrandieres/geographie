<?php 

class Requete
{
    /**
     * @return array 
     */
    public static function request($url)
    {
        $response_json = file_get_contents($url);
        $response_array = json_decode($response_json);
        return $response_array;
    }

    /**
     * @return string
     */
    public static function get($var)
    {
        if (isset($var))
        {
            return $var;
        }
    }
}